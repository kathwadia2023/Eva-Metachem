import SEO from "../components/SEO";
import { company } from "../data/products";
import "./LegalPage.css";

export default function PrivacyPolicy() {
  return (
    <>
      <SEO
        title="Privacy Policy"
        description="How EVA METACHEM collects, uses and protects information submitted through this website."
        path="/privacy-policy"
      />
      <div className="container legal-page">
        <h1>Privacy Policy</h1>
        <p className="legal-page__updated">Placeholder — to be reviewed by EVA METACHEM before publishing.</p>
        <div className="legal-page__body">
          <p>
            This page outlines, in general terms, how EVA METACHEM handles information submitted
            through this website. It is a placeholder structure and should be reviewed and
            finalized by EVA METACHEM (with legal counsel where appropriate) before the site goes
            live.
          </p>
          <h2>Information We Collect</h2>
          <p>
            When you submit the inquiry form, we collect the details you provide &mdash; such as
            your name, company, email, phone number, country and product requirement &mdash; in
            order to respond to your inquiry.
          </p>
          <h2>How We Use Information</h2>
          <ul>
            <li>To respond to product and quotation inquiries.</li>
            <li>To maintain records of business communication.</li>
            <li>To improve our products and services.</li>
          </ul>
          <h2>Contact</h2>
          <p>
            Questions about this policy can be sent to{" "}
            <a href={`mailto:${company.email}`}>{company.email}</a>.
          </p>
        </div>
      </div>
    </>
  );
}
